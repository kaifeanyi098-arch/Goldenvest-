# GoldenVest — test-mode investment platform starter

This is a runnable **development starter**, not a live investment business. It includes a responsive black-and-gold interface, email/password registration, hashed passwords, server-side sessions, SQLite persistence, deposit/withdrawal request records, and a basic admin review route.

## Included choices
- Asset focus: Bitcoin (BTC)
- Funding request types: Nigerian naira bank transfer and Bitcoin
- Currency and transaction records are stored as user-submitted request metadata.
- No payment processor, blockchain wallet, custody service, live price feed, profit engine, or real-money movement is integrated.
- Admin review only changes a request's test status. It never credits spendable balances.

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Set `SESSION_SECRET` to a long random secret.
4. In this folder run:
   ```sh
   npm install
   npm start
   ```
5. Open `http://localhost:3000`.

The database is created under `data/`. Do not commit `.env` or database files.

## Make a test admin
1. Register your normal test user through the website.
2. Stop the server.
3. Open a terminal in this project and run:
   ```sh
   node -e "const D=require('better-sqlite3'); const d=new D('data/goldenvest.db'); const email=process.argv[1]; const r=d.prepare(\"UPDATE users SET role='admin' WHERE email=?\").run(email); console.log('Rows updated:',r.changes)" your-email@example.com
   ```
4. Start the server again and sign in as that user. The admin panel appears.

## Before any real-money use
**Do not use this starter to accept public deposits or investments.** It is not production-ready for regulated financial activity. Before a public launch, obtain qualified Nigerian legal/compliance advice about the business structure and all applicable SEC, CBN, tax, AML/KYC, data-protection, consumer-protection, and virtual-asset requirements. Confirm the correct approvals with the relevant authorities and payment providers.

A production build needs, at minimum:
- A threat model and independent security review, CSRF token protection, secure recovery and email verification, stronger audit logging, monitoring, backups, and secret management.
- A proper accounting ledger with immutable entries and reconciliation; no user-editable balances.
- A licensed/approved payment provider for NGN bank transfers and a vetted Bitcoin custody/wallet provider or a non-custodial flow designed by qualified specialists.
- Verified blockchain transaction monitoring, confirmations, sanctions/AML controls, address validation, idempotent webhooks, and incident response.
- A documented, legally reviewed investment product, clear risk disclosures, fee/withdrawal terms, and a truthful way to calculate profit/loss from actual underlying activity. Do not promise guaranteed returns.
- Deployment over HTTPS with production-grade database, backups, access controls, logging, rate limits, and privacy policy/terms reviewed by counsel.

This project is intentionally configured to avoid moving funds or showing fabricated profits. The “approve” button is a test status change only.
